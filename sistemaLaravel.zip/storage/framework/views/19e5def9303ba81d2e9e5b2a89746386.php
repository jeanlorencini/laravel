

<?php $__env->startSection('content'); ?>
    <h1>Sistema de Contas de Jogos</h1>  

    <div id="container">
        <div id="cadastro">
            <h2>Cadastrar Conta de Jogo</h2>
            
            <form id="form-cadastro" action="<?php echo e(url('/cadastrar-conta')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <select id="jogo-select" name="jogo">
                    <option value="">Selecione um jogo</option>
                    <option value="novo">Novo jogo</option>
                </select>

                <label for="usuario">Usuário:</label>
                <input type="text" id="usuario" name="usuario">

                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha">

                <button type="submit" id="btn-cadastrar">Cadastrar</button>
            </form>

            <div id="msg-cadastro"></div>
        </div>

        <div id="pesquisa">
            <h2>Pesquisar Contas de Jogos</h2>

            <div class="search-input">
                <form id="form-pesquisa" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <input type="text" id="jogoInput" placeholder="Digite o nome do jogo">
                    
                    <div id="suggestions"></div>
                    
                  
                </form>
            </div>

            <div id="msg-pesquisa"></div>
            <div id="resultado"></div>
        </div>
    </div>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH M:\wamp64\www\sistemaLaravel\resources\views/cadastro.blade.php ENDPATH**/ ?>